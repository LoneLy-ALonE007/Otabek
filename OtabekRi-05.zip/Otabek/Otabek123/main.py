import tkinter as tk
from tkinter import PhotoImage


class SampleAPP(tk.Tk):
    def __init__(self, *arg, **kwargs):
        tk.Tk.__init__(self, *arg, **kwargs)
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (StartPage, MenuPage, EndPage):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame

            frame.grid(row=0, column=0, sticky="nsew")

            self.show_frame("StartPage")

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        frame.tkraise()


class StartPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        self.controller.title('Airport')
        self.controller.state('zoomed')
        self.controller.geometry("1300x900")



        self.backGroundImage = PhotoImage(file=r"img/airport.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)

        big_label = tk.Label(self, text=('Airport \n"вес мирь"'), font=('Bernard MT Condensed', 50, 'bold'), fg="#1989FA"
                              , bg="#eee")
        big_label.place(x=0 , y=0)


        login_label = tk.Label(self, text="ENTER YOUR LOGIN", font=('Bernard MT Condensed', 15, 'bold'), fg="#555",
                               bg="#fff")
        login_label.place(x=1100, y=50)

        my_login = tk.StringVar()
        login_entry = tk.Entry(self, textvariable=my_login, font=('Bernard MT Condensed', 15, 'bold'), fg="#333",
                               bg="#fff")
        login_entry.place(x=1100, y=80)

        bilet_label = tk.Label(self, text="ENTER YOUR PASSPORT", font=('Bernard MT Condensed', 15, 'bold'), fg="#555",
                               bg="#fff")
        bilet_label.place(x=850 ,y=150)

        my_passport = tk.StringVar()
        passport_entry = tk.Entry(self, textvariable=my_passport, font=('Bernard MT Condensed', 15, 'bold'), fg="#333",
                               bg="#fff")
        passport_entry.place(x=850, y=180 )

        password_label = tk.Label(self, text="ENTER YOUR PASSWORD", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="#555", bg="#fff")
        password_label.place(x=550 , y=250)

        my_password = tk.StringVar()
        password_entry = tk.Entry(self, textvariable=my_password, font=('Bernard MT Condensed', 15, 'bold'), fg="#333",
                                  bg="#fff")
        password_entry.place(x=550, y=280)

        def check_password():
            if my_password.get() == "1111" and my_login.get() == "joker" and my_passport.get() == "AA1234567":
                controller.show_frame('MenuPage')

            elif my_password.get() == "2222" and my_login.get() == "poker" and my_passport.get() == "AB7654321":
                controller.show_frame('EndPage')
            elif my_password.get() == "" or my_login.get() == "" or my_passport.get() == "":
                right_label['text'] = "FILL IN THE BLANKS!!! "
            elif my_password.get() == "2222" and my_login.get() == "poker" and my_passport.get() != "AB7654321":
                right_label['text'] = "Wrong passport "
            elif my_password.get() == "1111" and my_login.get() == "joker" and my_passport.get() != "AA1234567":
                right_label['text'] = "Wrong passport "
            elif my_password.get() != "1111" and my_login.get() == "joker" and my_passport.get() == "AA1234567":
                right_label['text'] = "Wrong password "
            elif my_password.get() != "2222" and my_login.get() == "poker" and my_passport.get() == "AB7654321":
                right_label['text'] = "Wrong password "
            elif my_password.get() == "2222" and my_login.get() != "poker" and my_passport.get() == "AB7654321":
                right_label['text'] = "Wrong login "
            elif my_password.get() == "1111" and my_login.get() != "joker" and my_passport.get() == "AA1234567":
                right_label['text'] = "Wrong login "
            elif my_password.get() != "2222" and my_login.get() != "poker" and my_passport.get() == "AB7654321":
                right_label['text'] = "Wrong login and password"
            elif my_password.get() != "1111" and my_login.get() != "joker" and my_passport.get() == "AA1234567":
                right_label['text'] = "Wrong login and password "
            elif my_password.get() == "2222" and my_login.get() != "poker" and my_passport.get() != "AB7654321":
                right_label['text'] = "Wrong login and passport "
            elif my_password.get() == "1111" and my_login.get() != "joker" and my_passport.get() != "AA1234567":
                right_label['text'] = "Wrong login and passport "
            elif my_password.get() != "1111" and my_login.get() == "joker" and my_passport.get() != "AA1234567":
                right_label['text'] = "Wrong passport and password "
            elif my_password.get() != "2222" and my_login.get() == "poker" and my_passport.get() != "AB7654321":
                right_label['text'] = "Wrong passport and password "
            elif my_password.get() == "" and my_login.get() == "" and my_passport.get() == "":
                right_label['text'] = "FILL IN THE BLANKS!!!"
            else:
                right_label['text'] = "Wrong login or password "

        password_button = tk.Button(self, text="click", command=check_password,
                                    font=('Bernard MT Condensed', 15, 'bold'), fg="#555", bg="#999", width='25')

        password_button.place(x=250, y=350)
        right_label = tk.Label(self, font=('Bernard MT Condensed', 40, 'bold'), fg="red", bg="#eee")
        right_label.place(x=650, y=500)


class MenuPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="black")
        self.controller = controller
        self.controller.geometry("1200x700")

        self.backGroundImage = PhotoImage(file=r"img/map2.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)
        big_lable = tk.Label(self, text="SALES DEPARTMENT", font=('Bernard MT Condensed', 50, 'bold'), fg="#fff",
                             bg="#0B0BBD")
        big_lable.place(x=100, y=50)

        def return_page():
            controller.show_frame('StartPage')

        return_button = tk.Button(self, text="BACK", command=return_page,
                                  font=('Bernard MT Condensed', 15, 'bold'), fg="#fff", bg="#999")
        return_button.place(x=1190, y=0)
        in_money_label = tk.Label(self, text="how much", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="#fff", bg="#0B0BBD")
        in_money_label.place(x=100, y=200)
        my_money = tk.IntVar()
        in_money_entry = tk.Entry(self, textvariable=my_money, font=('Bernard MT Condensed', 15, 'bold'), fg="#555",
                                  bg="#fff")
        in_money_entry.place(x=100, y=250)

        in_money_label = tk.Label(self, font=('Bernard MT Condensed', 25, 'bold'),
                                  fg="#fff", bg="#0B0BBD")
        in_money_label.place(x=900, y=200)

        cash_label = tk.Label(self, text="summa", font=('Bernard MT Condensed', 15, 'bold'),
                              fg="#fff", bg="#0B0BBD")
        cash_label.place(x=100, y=320)
        my_cash = tk.IntVar()
        cash_entry = tk.Entry(self, textvariable=my_cash, font=('Bernard MT Condensed', 15, 'bold'), fg="#555",
                              bg="#fff")
        cash_entry.place(x=100, y=370)

        def get_cash():
            global new_cash
            in_money_label['text'] = my_money.get()
            new_cash = int(my_money.get()) * int(my_cash.get())
            cash_label['text'] = new_cash
            in_city1_label['text'] = my_city1.get()
            in_city2_label['text'] = my_city2.get()

        cash_label = tk.Label(self, font=('Bernard MT Condensed', 25, 'bold'),
                              fg="#fff", bg="#0B0BBD")
        cash_label.place(x=900, y=300)

        cash_button = tk.Button(self, text="Check", command=get_cash,
                                font=('Bernard MT Condensed', 25, 'bold'), fg="green", bg="#0B0BBD", width='25')
        cash_button.place(x=100, y=450)
        in_text_label = tk.Label(self, text="Ticket:", font=('Bernard MT Condensed', 25, 'bold'),
                                 fg="red", bg="#0B0BBD")
        in_text_label.place(x=800, y=200)
        in_text1_label = tk.Label(self, text="Money:", font=('Bernard MT Condensed', 25, 'bold'),
                                  fg="red", bg="#0B0BBD")
        in_text1_label.place(x=800, y=300)
        in_city1_label = tk.Label(self, text="where from?", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="#fff", bg="#0B0BBD")
        in_city1_label.place(x=400, y=200)
        my_city1 = tk.StringVar()
        in_city1_entry = tk.Entry(self, textvariable=my_city1, font=('Bernard MT Condensed', 15, 'bold'), fg="#555",
                                  bg="#fff")
        in_city1_entry.place(x=400, y=250)

        in_city1_label = tk.Label(self, font=('Bernard MT Condensed', 25, 'bold'),
                                  fg="#fff", bg="#0B0BBD")
        in_city1_label.place(x=900, y=400)
        in_city11_label = tk.Label(self, text="From  :", font=('Bernard MT Condensed', 25, 'bold'),
                                  fg="red", bg="#0B0BBD")
        in_city11_label.place(x=800, y=400)
        in_city2_label = tk.Label(self, text="where to?", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="#fff", bg="#0B0BBD")
        in_city2_label.place(x=400, y=320)
        my_city2 = tk.StringVar()
        in_city2_entry = tk.Entry(self, textvariable=my_city2, font=('Bernard MT Condensed', 15, 'bold'), fg="#555",
                                  bg="#fff")
        in_city2_entry.place(x=400, y=370)

        in_city2_label = tk.Label(self, font=('Bernard MT Condensed', 25, 'bold'),
                                  fg="#fff", bg="#0B0BBD")
        in_city2_label.place(x=900, y=500)
        in_city22_label = tk.Label(self, text="To      :", font=('Bernard MT Condensed', 25, 'bold'),
                                   fg="red", bg="#0B0BBD")
        in_city22_label.place(x=800, y=500)

class EndPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#FF7578")
        self.controller = controller
        self.controller.title('Airport')
        self.controller.state('zoomed')
        self.controller.geometry("1300x900")

        self.backGroundImage = PhotoImage(file=r"img/girl.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)
        big_lable = tk.Label(self, text="SALES DEPARTMENT", font=('Bernard MT Condensed', 50, 'bold'), fg="#555",
                             bg="#fff")
        big_lable.place(x=100 , y=50)

        def return_page():
            controller.show_frame('StartPage')

        return_button = tk.Button(self, text="BACK", command=return_page,
                                  font=('Bernard MT Condensed', 15, 'bold'), fg="#555", bg="#999")
        return_button.place(x=1190, y=0)
        in_money_label = tk.Label(self, text="how much", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="blue", bg="#fff")
        in_money_label.place(x=100 , y=200)
        my_money = tk.IntVar()
        in_money_entry = tk.Entry(self, textvariable=my_money, font=('Bernard MT Condensed', 15, 'bold'), fg="#555",
                                  bg="#fff")
        in_money_entry.place(x=100, y=250)

        in_money_label = tk.Label(self, font=('Bernard MT Condensed', 25, 'bold'),
                                  fg="#000", bg="#fff")
        in_money_label.place(x=600, y=200)


        cash_label = tk.Label(self, text="summa", font=('Bernard MT Condensed', 15, 'bold'),
                              fg="blue", bg="#fff")
        cash_label.place(x=100, y=320)
        my_cash = tk.IntVar()
        cash_entry = tk.Entry(self, textvariable=my_cash, font=('Bernard MT Condensed', 15, 'bold'), fg="#555",
                              bg="#fff")
        cash_entry.place(x=100, y=370)

        def get_cash():
            global new_cash
            in_money_label['text'] = my_money.get()
            new_cash = int(my_money.get()) * int(my_cash.get())
            cash_label['text'] = new_cash



        cash_label = tk.Label(self, font=('Bernard MT Condensed', 25, 'bold'),
                              fg="#000", bg="#fff")
        cash_label.place(x=600, y=300)

        cash_button = tk.Button(self, text="Check", command=get_cash,
                                font=('Bernard MT Condensed', 25, 'bold'), fg="green", bg="#fff", width='25')
        cash_button.place(x=100, y=450)
        in_text_label = tk.Label(self, text="Ticket:", font=('Bernard MT Condensed', 25, 'bold'),
                                  fg="red", bg="#fff")
        in_text_label.place(x=500, y=200)
        in_text1_label = tk.Label(self, text="Money:", font=('Bernard MT Condensed', 25, 'bold'),
                                  fg="red", bg="#fff")
        in_text1_label.place(x=500, y=300)






if __name__== "__main__":
    app = SampleAPP()
    app.mainloop()

